<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Yaform Mail</title>
</head>
<body>
    <h1><?php echo e($msg); ?></h1>
    <p><?php echo e($subjec); ?></p>
    <a href="<?php echo e($link); ?>"> form link </a>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel projects\company\yaform-2\resources\views/mails/formMail.blade.php ENDPATH**/ ?>